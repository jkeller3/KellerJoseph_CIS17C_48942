/* 
 * File:   AdjList.h
 * Author: rcc
 *
 * Created on December 14, 2015, 4:53 PM
 */

#ifndef ADJLIST_H
#define	ADJLIST_H

struct AdjList{
    struct AdjListNode *head;
};

#endif	/* ADJLIST_H */

